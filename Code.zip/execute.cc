#include "mipsim.hpp"

Stats stats;
Caches caches(0);

unsigned int signExtend16to32ui(short i) {
  return static_cast<unsigned int>(static_cast<int>(i));
}

int signExtend8to32i(char c) {
  return static_cast<int>(c);
}

int signExtend16to32i(short i) {
  return static_cast<int>(i);
}


void rStats() {
   stats.numRType++;
   stats.numRegWrites++;
   stats.numRegReads += 2;
}

void iStats() {
   stats.numIType++;
   stats.numRegReads++;
   stats.numRegWrites++;
}

void noOp() {
   stats.instrs--;
}

void jStats() {
   stats.numJType++;
}

void bStats() {
   stats.numIType++;
   stats.numRegReads++;  
}

void checkForwards(unsigned int reg) {
  Data32 reg2 = imem[pc];
  RType rTypeForward(reg2);
  IType iTypeForward(reg2);

///////////////////////////////////////////////////////////
  if (reg2 != Data32(0)) {
    switch(reg2.classifyType(reg2)) {
      case R_TYPE:
        if (rTypeForward.rs == reg || rTypeForward.rt == reg)
          stats.forwardFromEX++;
        if (rTypeForward.rd == reg)
          return;
      break;
      case I_TYPE:
        if (iTypeForward.rs == reg || ((iTypeForward.op==4 || iTypeForward.op==5 || iTypeForward.op==43 || iTypeForward.op==40) && iTypeForward.rt==reg))
          stats.forwardFromEX++;
        if (iTypeForward.rt == reg)
          return;
      break;
    }
  }

   if (imem.inRange(pc + 4)) {
     reg2 = imem[pc + 4];
     RType rTypeForward2(reg2);
     IType iTypeForward2(reg2);

     if (reg2 != Data32(0) ) {
       switch(reg2.classifyType(reg2)) {
         case R_TYPE:
           if (rTypeForward2.rs == reg || rTypeForward2.rt == reg)
             stats.forwardFromMEM++;
           break;
         case I_TYPE:
           if (iTypeForward2.rs == reg || ((iTypeForward2.op==4 || iTypeForward2.op==5 || iTypeForward2.op==43 || iTypeForward2.op==40) && iTypeForward2.rt==reg))
             stats.forwardFromMEM++;
         break;
       }
     }
   }
}
///////////////////////////////////////////////////////////


void loadHazard(unsigned int reg) {
   Data32 reg2 = imem[pc];
   Type type = reg2.classifyType(reg2);
   RType rTypeHaz(reg2); 
   IType iTypeHaz(reg2);

   if (type == R_TYPE && (rTypeHaz.rs == reg|| rTypeHaz.rt == reg))  {
      stats.loadHasLoadUseHazard++;
   }
   else if (type == I_TYPE && (iTypeHaz.rs == reg || (iTypeHaz.rt == reg 
    && (iTypeHaz.op == 4 || iTypeHaz.op == 5 || iTypeHaz.op == 43 
    || iTypeHaz.op == 40)))) { 
      stats.loadHasLoadUseHazard++;
   }
   else {
      if (reg2 == Data32(0))
         stats.loadHasLoadUseStall++;
      stats.loadHasNoLoadUseHazard++;
   }  
} 


void execute() {
  Data32 instr = imem[pc];
  Data32 temp(0);
  GenericType rg(instr);
  RType rt(instr);
  IType ri(instr);
  JType rj(instr);
  unsigned int pctarget = pc + 4;
  unsigned int addr;
  static unsigned int jumppc;
  static bool jump = false;
  bool taken;
  stats.instrs++;
  stats.cycles++;

  if(jump) {
    pc = jumppc;
    jump = false;
  }
  else
    pc = pctarget;

  switch(rg.op) {
  case OP_SPECIAL:
    if (instr != Data32(0) && rg.func != SP_JR)
      checkForwards(rt.rd);
    switch(rg.func) {
    case SP_AND:
      rf.write(rt.rd, rf[rt.rs] & rf[rt.rt]);
      rStats();
      break;
    case SP_ADD:
    case SP_ADDU:
      rf.write(rt.rd, rf[rt.rs] + rf[rt.rt]);
      rStats();
      break;
    case SP_JALR:
      rf.write(rt.rd, pc + 4);
      stats.numRegWrites++;
    case SP_JR:
       if (imem[pc] == Data32(0))
         stats.hasUselessJumpDelaySlot++;
       else
         stats.hasUsefulJumpDelaySlot++;

      jump = true;
      jumppc = rf[rt.rs];
      stats.numRegReads++;
      stats.numRType++;
      break;
    case SP_NOR:
      rf.write(rt.rd, ~(rf[rt.rs] | rf[rt.rt]));
      rStats();
      break;
    case SP_OR:
      rf.write(rt.rd, rf[rt.rs] | rf[rt.rt]);
      rStats();
      break;
    case SP_SLL:      
      if(instr == Data32(0))
         noOp();
      else {
         rStats();
         stats.numRegReads--;
         rf.write(rt.rd, rf[rt.rt] << rt.sa);
      }
      break;
    case SP_SLLV:
      rf.write(rt.rd, rf[rt.rt] << rf[rt.rs]);
      rStats();
      break;
    case SP_SLT:
      rf.write(rt.rd, (signed) rf[rt.rs] < (signed) rf[rt.rt] ? 1 : 0);
      rStats();
      break;
    case SP_SRA:
      rf.write(rt.rd, (signed) rf[rt.rt] >> rt.sa);
      stats.numRType++;
      stats.numRegReads++;
      stats.numRegWrites++;
      break;
    case SP_SRAV:
      rf.write(rt.rd, (signed) rf[rt.rt] >> rf[rt.rs]);
      rStats();
      break;
    case SP_SRL:
      rf.write(rt.rd, rf[rt.rt] >> rt.sa);
      stats.numRType++;
      stats.numRegReads++;
      stats.numRegWrites++;
      break;
    case SP_SRLV:
      rf.write(rt.rd, rf[rt.rt] >> rf[rt.rs]);
      rStats();
      break;
    case SP_SUB:
      rf.write(rt.rd, (signed) rf[rt.rs] - (signed) rf[rt.rt]);
      rStats();
      break;
    case SP_SUBU:
      rf.write(rt.rd, rf[rt.rs] - rf[rt.rt]);
      rStats();
      break;
    case SP_XOR:
      rf.write(rt.rd, rf[rt.rs] ^ rf[rt.rt]);
      rStats();
      break;
    default:
      cout << "Unsupported instruction: ";
      instr.printI(instr);
      exit(1);
      break;
    }
    break;
  case OP_ADDI:
///////////////////////////////////////////////////////////
    checkForwards(ri.rt);
///////////////////////////////////////////////////////////
    rf.write(ri.rt, rf[ri.rs] + signExtend16to32i(ri.imm));
    iStats();
    break;
  case OP_ADDIU:
///////////////////////////////////////////////////////////
   if(imem.inRange(pc))    
      checkForwards(ri.rt);
///////////////////////////////////////////////////////////
    rf.write(ri.rt, rf[ri.rs] + signExtend16to32ui(ri.imm));
    iStats();
    break;
  case OP_ANDI:
///////////////////////////////////////////////////////////
    checkForwards(ri.rt);
///////////////////////////////////////////////////////////
    rf.write(ri.rt, rf[ri.rs] & signExtend16to32ui(ri.imm));
    iStats();
    break;
  case OP_BEQ:
    if (imem[pc] == Data32(0))
      stats.hasUselessBranchDelaySlot++;
    else
      stats.hasUsefulBranchDelaySlot++;

    if (rf[ri.rs] == rf[ri.rt]) {
      jump = true;
      jumppc = pc + (signExtend16to32ui(ri.imm) << 2);
   
      if (ri.imm < 0)
         stats.numBackwardBranchesTaken++;
      else
         stats.numForwardBranchesTaken++;
    }
    else if (ri.imm < 0)
      stats.numBackwardBranchesNotTaken++;
    else
      stats.numForwardBranchesNotTaken++;

    bStats();
    stats.numRegReads++;
    break;
  case OP_BGTZ:
    if (imem[pc] == Data32(0))
      stats.hasUselessBranchDelaySlot++;
    else
      stats.hasUsefulBranchDelaySlot++;

    if ((signed) rf[ri.rs] > 0) {
      jump = true;
      jumppc = pc + (signExtend16to32ui(ri.imm) << 2);
   
      if (ri.imm < 0)
         stats.numBackwardBranchesTaken++;
      else
         stats.numForwardBranchesTaken++;
    }
    else if (ri.imm < 0)
      stats.numBackwardBranchesNotTaken++;
    else
      stats.numForwardBranchesNotTaken++;

    bStats();
    break;
  case OP_BLEZ:
    if (imem[pc] == Data32(0))
      stats.hasUselessBranchDelaySlot++;
    else
      stats.hasUsefulBranchDelaySlot++;

    if ((signed) rf[ri.rs] <= 0) {
      jump = true;
      jumppc = pc + (signExtend16to32ui(ri.imm) << 2);
   
      if (ri.imm < 0)
         stats.numBackwardBranchesTaken++;
      else
         stats.numForwardBranchesTaken++;
    }
    else if (ri.imm < 0)
      stats.numBackwardBranchesNotTaken++;
    else
      stats.numForwardBranchesNotTaken++;

    bStats();
    break;
  case OP_BNE:
    if (imem[pc] == Data32(0))
      stats.hasUselessBranchDelaySlot++;
    else
      stats.hasUsefulBranchDelaySlot++;

    if (rf[ri.rs] != rf[ri.rt]) {
      jump = true;
      jumppc = pc + (signExtend16to32ui(ri.imm) << 2);
   
      if (ri.imm < 0)
         stats.numBackwardBranchesTaken++;
      else
         stats.numForwardBranchesTaken++;
    }
    else if (ri.imm < 0)
      stats.numBackwardBranchesNotTaken++;
    else
      stats.numForwardBranchesNotTaken++;
    
    bStats();
    stats.numRegReads++;
    break;
  case OP_JAL:
    rf.write(31, pc + 4);
    stats.numRegWrites++;
  case OP_J:
    if (imem[pc] == Data32(0))
      stats.hasUselessJumpDelaySlot++;
    else
      stats.hasUsefulJumpDelaySlot++;

    jump = true;
    jumppc = (pc & 0xf0000000) | (rj.target << 2);
    jStats();
    break;
  case OP_LB:
///////////////////////////////////////////////////////////
    checkForwards(ri.rt);
///////////////////////////////////////////////////////////
    addr = rf[ri.rs] + signExtend16to32ui(ri.imm);
    caches.access(addr);
    rf.write(ri.rt, signExtend8to32i(dmem[addr].data_ubyte4(0)));
    iStats();
    stats.numMemReads++;
    loadHazard(ri.rt);
    break;
  case OP_LBU:
///////////////////////////////////////////////////////////
    checkForwards(ri.rt);
///////////////////////////////////////////////////////////
    addr = rf[ri.rs] + signExtend16to32ui(ri.imm);
    caches.access(addr);
    rf.write(ri.rt, dmem[addr].data_ubyte4(0));
    iStats();
    stats.numMemReads++;
    loadHazard(ri.rt);
    break;
  case OP_LUI:
///////////////////////////////////////////////////////////
    checkForwards(ri.rt);
///////////////////////////////////////////////////////////
    rf.write(ri.rt, ri.imm << 16);
    stats.numIType++;
    stats.numRegWrites++;
    break;
  case OP_LW:
///////////////////////////////////////////////////////////
    checkForwards(ri.rt);
///////////////////////////////////////////////////////////
    addr = rf[ri.rs] + signExtend16to32ui(ri.imm);
    caches.access(addr);
    rf.write(ri.rt, dmem[addr]);
    iStats();
    stats.numMemReads++;
    loadHazard(ri.rt);
    break;
  case OP_ORI:
///////////////////////////////////////////////////////////
    checkForwards(ri.rt);
///////////////////////////////////////////////////////////
    rf.write(ri.rt, rf[ri.rs] | 0x0000ffff & ri.imm);
    iStats();
    break;
  case OP_SB:
    addr = rf[ri.rs] + signExtend16to32i(ri.imm);
    caches.access(addr);
    temp = dmem[addr];
    temp.set_data_ubyte4(0, rf[ri.rt].data_ubyte4(3));
    dmem.write(addr, temp);

    stats.numIType++;
    stats.numRegReads += 2;
    stats.numMemWrites++;
    break;
  case OP_SLTI:
///////////////////////////////////////////////////////////
    checkForwards(ri.rt);
///////////////////////////////////////////////////////////
    rf.write(ri.rt, (signed) rf[ri.rs] < (signed) ri.imm ? 1 : 0);
    iStats();
    break;
  case OP_SLTIU:
///////////////////////////////////////////////////////////
    checkForwards(ri.rt);
///////////////////////////////////////////////////////////
    rf.write(ri.rt, (unsigned) rf[ri.rs] < (unsigned) ri.imm ? 1 : 0);
    iStats();
    break;
  case OP_SW:
    addr = rf[ri.rs] + signExtend16to32ui(ri.imm);
    caches.access(addr);
    dmem.write(addr, rf[ri.rt]);
   
    stats.numIType++;
    stats.numRegReads += 2;
    stats.numMemWrites++;
    break;
  case OP_XORI:
///////////////////////////////////////////////////////////
    checkForwards(ri.rt);
///////////////////////////////////////////////////////////
    rf.write(ri.rt, rf[ri.rs] ^ signExtend16to32ui(ri.imm));
    iStats();
    break;
  default:
    cout << "Unsupported instruction: ";
    instr.printI(instr);
    exit(1);
    break;
  }
}
